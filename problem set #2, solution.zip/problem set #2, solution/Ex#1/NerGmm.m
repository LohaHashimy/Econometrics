% Execise #1 
%Estimating Nerlov Model Using Maximum likelihood Estimator.
% I have used the codes provided by Professor Creel in the class note
% examples and have personalized them a little bit.
clear all;
close all;
clc;
[~, ~, raw] = xlsread('D:\matlab\bin\Problem set#1,solution\NerlovData.xlsx','Sheet1','A2:F146');
data = reshape([raw{:}],size(raw));
Firm = data(:,1);
TC = data(:,2);
Q = data(:,3);
PL = data(:,4);
PF = data(:,5);
PK = data(:,6);
data= log(data);
n = length(data);
y = data(:,2);
x = data(:,3:6);
x = [ones(n,1), x];
%theta_int=[-3.5265; 0.720349; 0.43643; 0.42652; -0.21989; 0.39236];%I have used 
%the True values of theta from the OLS model in prob#1

%testing for other initial theta or start value
theta_int=[zeros(5,1); 0.5];


%estimating the MLE estimator using fminunc, the unconstrained model
[betaMLE, log_L] =fminunc(@(theta) -Loha(theta,y,x), theta_int);
log_L= -log_L; %changes the minimization to mazimization
betaMLE = betaMLE(1:5,:)



