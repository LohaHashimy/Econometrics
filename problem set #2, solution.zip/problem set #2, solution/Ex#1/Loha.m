%I have used the codes provided by Creel for the linear model log-likelihood 
% y = x*b+e, with e~N(0,s^2)
% the parameter theta = [b' s]
% this file is used for demonstration of MLE, to compare to OLS
function cdf = Loha(theta,y,x)
    k = size(theta,1);
    b = theta(1:k-1,:);
    s = theta(k,:);
    err = y - x*b;
    % This is the likelihood functon for each observation
    cdf = -log(sqrt(2*pi)) - log(s) - err.*err/(2*s^2);
    % in orther to aggregate it we have to use the following code
    cdf = mean(cdf);
end