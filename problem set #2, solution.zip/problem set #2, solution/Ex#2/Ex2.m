% Execise #2 
%Estimating Nerlov Model Using Maximum likelihood Estimator.
% I have used the codes provided by Professor Creel in the econometrics.iso
% examples and I have personalized them a little bit.
clear all;
close all;
clc;
[~, ~, raw] = xlsread('D:\matlab\bin\Problem set#1,solution\NerlovData.xlsx','Sheet1','A2:F146');
data = reshape([raw{:}],size(raw));
Firm = data(:,1);
TC = data(:,2);
Q = data(:,3);
PL = data(:,4);
PF = data(:,5);
PK = data(:,6);
data= log(data);
n = length(data);
y = data(:,2);
x = data(:,3:6);
x = [ones(n,1), x];
theta_int=[-3.5265; 0.720349; 0.43643; 0.42652; -0.21989; 0.39236]%I have used 
%the True values of theta from the OLS model in prob#1

%testing for other initial theta or start value
%theta_int=[zeros(5,1); 0.5];


%estimating the MLE estimator using fminunc, the unconstrained model
[betaMLE, log_L_U] = fminunc(@(theta) -Loha(theta,y,x), theta_int)
log_L_U= -log_L_U %changes the minimization to mazimization

%Exercise 2a:
%Estimating the restricted Nerlov Model using MLE and fmincon.
dof=1
R=[0 0 1 1 1 0];%restrictions of BL+BF+BK=1, homogeniety of degree 1
r=1;
[theta_hat_r, log_L_R]= fmincon(@(theta) -Loha(theta,y,x),theta_int,[],[],R,r)
log_L_R= -log_L_R
%Use the likelihood ratio test to assess whether the data provide enough 
%evidence to favor the unrestricted model over the restricted model.
[h,pValue,stat] = lratiotest(log_L_U,log_L_R,dof);
h
pValue
stat

%Exercise 2b:
dof=1
R_b=[0 1 0 0 0 0];%restrictions of BQ=1 or CRTS
r_b=1;
[theta_hat_r_b, log_L_R_b]= fmincon(@(theta) -Loha(theta,y,x),theta_int,[],[],R_b,r_b)
log_L_R_b= -log_L_R_b
[h,pValue,stat] = lratiotest(log_L_U,log_L_R_b,dof);
h
pValue
stat
%Exercise 2c:

dof=2
R_c=[0 0 1 1 1 0;0 1 0 0 0 0];%Homogeniety of degree 1 and CRTS LR joint test
r_c=[1;1]
[theta_hat_r_b, log_L_R_c]= fmincon(@(theta) -Loha(theta,y,x),theta_int,[],[],R_c,r_c)
log_L_R_c= -log_L_R_c
[h,pValue,stat] = lratiotest(log_L_U,log_L_R_c,dof);
h
pValue
stat

