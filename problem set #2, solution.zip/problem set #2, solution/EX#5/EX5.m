%Exercise #5
%In This Exercisr, I am estimatting the probit and logi model of the
%decision of having an affair
%using the Extramarital Affairs Data_1997

clear all;
close all;
clc;
%% Import the data
[~, ~, raw] = xlsread('D:\matlab\bin\problem set #2, solution\Data_Fair_1977.xlsx','Data_Fair_1977','A2:J602');
%% Create output variable
data = reshape([raw{:}],size(raw));
%% Allocate imported array to column variable names
ID = data(:,1);
n_aff = data(:,2);
gender = data(:,3);
age = data(:,4);
y_marr = data(:,5);
children = data(:,6);
rel = data(:,7);
educ = data(:,8);
occup = data(:,9);
marr_rat = data(:,10);
%Exercise 2a:
%generating dummy for the independent variable n_aff
%
s=length(n_aff);
dummy_aff=zeros(1,s);
for k=1:1:s
    if n_aff(k)>0
        dummy_aff(k)=1;
    else
        dummy_aff(k)=0;
    end
end
%Exercise 2b:
%Probit model 
dummy_aff=dummy_aff';
Y=dummy_aff;
x1= gender;
x2= age;
x3= y_marr;
x4= children;
x5=rel;
x6=educ;
x7=occup;
x8=marr_rat;
nobs=size(ID,1)
X=[ones(nobs,1) x1 x2 x3 x4 x5 x6 x7 x8];
theta_int = zeros(9,1);
[theta_hat_prob, Log_lik] = fminunc(@(theta) -probit_ml(theta, Y, X), theta_int)
%Exercise 2c:
[theta_hat_logit, Log_lik] = fminunc(@(theta) -logit_ml(theta, Y, X), theta_int)