%This function is used to setimate the probit regression for the 
%Fair data
function [log_den prob] = probit_ml(theta, y, x)
	prob= normcdf(x*theta);
	log_den = y .* log(prob) + (1 - y) .* log(1 - prob);
    log_den = mean(log_den);
end