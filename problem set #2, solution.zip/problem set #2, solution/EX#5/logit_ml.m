%This function is used to setimate the logit regression for the 
%Fair data
function [log_den prob] = logit_ml(theta, y, x)
	prob = 1 ./ (1 + exp(-x*theta));
	log_den = y .* log(prob) + (1 - y) .* log(1 - prob);
	log_den = mean(log_den);
end